# RootFund — React Landing Page

## Project Structure

```
rootfund/
├── index.html
├── package.json
├── vite.config.js
└── src/
    ├── main.jsx           ← Entry point
    ├── App.jsx            ← Landing page
    ├── App.css            ← All styles
    ├── LiquidEther.jsx    ← WebGL fluid background
    └── LiquidEther.css    ← Fluid canvas styles
```

## Setup

```bash
npm install
npm run dev
```

Then open http://localhost:5173

## Adding Google Sign-In

In `src/App.jsx`, find the `openAuth` function and replace the alert with your OAuth URL:

```js
const openAuth = () => {
  window.location.href = 'https://accounts.google.com/o/oauth2/v2/auth?...your-params';
};
```

## Build for Production

```bash
npm run build
```

Output goes to `dist/` — deploy anywhere (Vercel, Netlify, etc.)
